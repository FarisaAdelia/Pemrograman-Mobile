import org.gradle.kotlin.dsl.implementation

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    id("org.jetbrains.kotlin.kapt")
    kotlin("plugin.serialization") version "1.9.10"
}

android {
    namespace = "com.example.modul5connecttotheinternetcopy"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.modul3scrollablelist"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    kotlinOptions {
        jvmTarget = "11"
    }
    buildFeatures {
        compose = true
    }
    kotlin {
        sourceSets.all {
            languageSettings.optIn("kotlinx.serialization.ExperimentalSerializationApi")
        }
    }
}

dependencies {

    // KTX (Kotlin Extensions) untuk fungsionalitas Android inti
    implementation(libs.androidx.core.ktx)

    // Lifecycle untuk ViewModel dan Coroutines dalam ViewModel
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.7.0") // Untuk viewModelScope
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.7.0") // Untuk viewModel() di Composable

    // Compose
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.ui)
    implementation(libs.androidx.ui.graphics)
    implementation(libs.androidx.ui.tooling.preview)
    implementation(libs.androidx.material3)
    implementation(libs.androidx.navigation.compose) // Untuk Navigasi Compose

    implementation("androidx.lifecycle:lifecycle-livedata-ktx:2.7.0")
    // Room Database
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1") // Untuk dukungan Coroutines
    kapt("androidx.room:room-compiler:2.6.1") // Annotation processor untuk Room
    // Anda sudah memiliki paging, jadi biarkan saja jika Anda memang menggunakannya
    implementation("androidx.paging:paging-runtime-ktx:3.2.1")
    implementation("androidx.room:room-paging:2.6.1")

    // Retrofit (untuk koneksi ke internet)
    implementation(libs.retrofit)

    // Kotlinx Serialization (untuk parsing JSON)
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.6.0") // Pastikan versi ini konsisten dengan plugin kotlin("plugin.serialization")
    implementation("com.jakewharton.retrofit:retrofit2-kotlinx-serialization-converter:0.8.0") // Converter Retrofit untuk Kotlinx Serialization

    // Coil (untuk memuat gambar dari URL, jika Anda berencana menampilkannya dari Picture.large)
    implementation(libs.coil.compose)

    // Pengujian
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(platform(libs.androidx.compose.bom))
    androidTestImplementation(libs.androidx.ui.test.junit4)
    debugImplementation(libs.androidx.ui.tooling)
    debugImplementation(libs.androidx.ui.test.manifest)
}