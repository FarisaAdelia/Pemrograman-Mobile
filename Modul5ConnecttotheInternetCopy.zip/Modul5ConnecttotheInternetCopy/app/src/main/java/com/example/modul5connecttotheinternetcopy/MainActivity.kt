package com.example.modul5connecttotheinternetcopy

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.net.toUri
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.modul5connecttotheinternetcopy.model.MovieItem
import com.example.modul5connecttotheinternetcopy.ui.theme.Modul3ScrollableListTheme
import com.example.modul5connecttotheinternetcopy.viewmodel.MovieViewModel
import com.example.modul5connecttotheinternetcopy.viewmodel.MovieViewModelFactory
import com.example.modul5connecttotheinternetcopy.viewmodel.UserViewModel
import com.example.modul5connecttotheinternetcopy.viewmodel.UserViewModelFactory


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Modul3ScrollableListTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    val movieViewModel: MovieViewModel = viewModel(factory = MovieViewModelFactory())
                    val userViewModel: UserViewModel = viewModel(factory = UserViewModelFactory(application))
                    MainScreen(movieViewModel, userViewModel)
                }
            }
        }
    }
}
@Composable
fun ProfileScreen(userViewModel: UserViewModel) {
    val user by userViewModel.user.collectAsState()
    val context = LocalContext.current

    LaunchedEffect(Unit) {
        userViewModel.fetchUser(true)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text("Profile", style = MaterialTheme.typography.titleLarge)
        Spacer(modifier = Modifier.height(16.dp))

        if (user != null) {
            Text("Name: ${user?.name?.title} ${user?.name?.first} ${user?.name?.last}")
            Text("Email: ${user?.email}")
            Text("Phone: ${user?.phone}")
            Text("Cell: ${user?.cell}")
            Text("Address: ${user?.location?.street?.number} ${user?.location?.street?.name}, ${user?.location?.city}, ${user?.location?.state}, ${user?.location?.country}, ${user?.location?.postcode}")
        } else {
            Text("Loading user data or no data available offline...")
        }

        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = {
            userViewModel.fetchUser(true)
        }) {
            Text("Refresh User")
        }
        Spacer(modifier = Modifier.height(8.dp))
        Button(onClick = {  }) {
            Text("Logout")
        }
    }
}

@Composable
fun MainScreen(
    viewModel: MovieViewModel,
    userViewModel: UserViewModel
) {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = "list") {
        composable("list") {
            MovieListScreen(navController, viewModel)
        }
        composable("detail") {
            val movie by viewModel.selectedMovie.collectAsState()
            movie?.let {
                DetailScreen(it)
            }
        }
        composable("profile") {
            ProfileScreen(userViewModel)
        }
    }
}


@Composable
fun MovieListScreen(navController: NavController, viewModel: MovieViewModel) {
    val context = LocalContext.current
    val movieList by viewModel.movies.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {
        Button(
            onClick = { navController.navigate("profile") },
            modifier = Modifier
                .padding(8.dp)
                .fillMaxWidth()
        ) {
            Text("Go to Profile")
        }

        LazyColumn(modifier = Modifier.padding(8.dp).weight(1f)) {
            items(movieList) { movie ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .padding(vertical = 8.dp)
                        .fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Image(
                            painter = painterResource(id = movie.imageResId),
                            contentDescription = movie.title,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(180.dp)
                                .clip(RoundedCornerShape(8.dp))
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(movie.title, fontWeight = FontWeight.Bold)
                            Text(movie.year)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Plot: ${movie.plot}", maxLines = 3)
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                            Button(onClick = {
                                viewModel.onImdbClick(movie)
                                val intent = Intent(Intent.ACTION_VIEW, movie.imdbLink.toUri())
                                context.startActivity(intent)
                            }) {
                                Text("IMDB")
                            }
                            Button(onClick = {
                                viewModel.selectMovie(movie)
                                viewModel.onDetailClick(movie)
                                navController.navigate("detail")
                            }) {
                                Text("Detail")
                            }
                        }
                    }
                }
            }
        }
    }
}


@Composable
fun DetailScreen(movie: MovieItem) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Image(
            painter = painterResource(id = movie.imageResId),
            contentDescription = movie.title,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxWidth()
                .height(250.dp)
                .clip(RoundedCornerShape(12.dp))
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(movie.title, style = MaterialTheme.typography.titleLarge)
        Text(movie.year, style = MaterialTheme.typography.labelMedium)
        Spacer(modifier = Modifier.height(8.dp))
        Text("Plot:", fontWeight = FontWeight.Bold)
        Text(movie.plot)
    }
}