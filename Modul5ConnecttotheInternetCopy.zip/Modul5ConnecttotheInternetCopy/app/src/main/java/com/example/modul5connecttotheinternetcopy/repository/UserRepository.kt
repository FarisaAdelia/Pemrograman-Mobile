package com.example.modul5connecttotheinternetcopy.data

import com.example.modul5connecttotheinternetcopy.model.User
import com.example.modul5connecttotheinternetcopy.ApiService
import com.example.modul5connecttotheinternetcopy.data.UserDao
import kotlinx.coroutines.flow.Flow

class UserRepository(private val apiService: ApiService, private val userDao: UserDao) {

    fun getUser(): Flow<User?> {
        return userDao.getUser()
    }

    suspend fun refreshUser() {
        try {
            val response = apiService.getRandomUser()
            val user = response.results.firstOrNull()
            if (user != null) {
                userDao.deleteAllUsers()
                userDao.insertUser(user)
            }
        } catch (e: Exception) {
            println("Error refreshing user: ${e.message}")
            throw e
        }
    }
}