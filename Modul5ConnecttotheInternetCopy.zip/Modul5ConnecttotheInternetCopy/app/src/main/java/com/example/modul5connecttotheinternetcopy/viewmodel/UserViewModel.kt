package com.example.modul5connecttotheinternetcopy.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.modul5connecttotheinternetcopy.data.UserRepository
import com.example.modul5connecttotheinternetcopy.model.User
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.launch

class UserViewModel(private val repository: UserRepository) : ViewModel() {
    val user: StateFlow<User?> = repository.getUser()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    init {
        fetchUser(true)
    }

    fun fetchUser(forceRefresh: Boolean = false) {
        viewModelScope.launch {
            if (forceRefresh) {
                try {
                    repository.refreshUser()
                } catch (e: Exception) {
                    println("Error fetching user from network: ${e.message}")
                }
            }
        }
    }
}
