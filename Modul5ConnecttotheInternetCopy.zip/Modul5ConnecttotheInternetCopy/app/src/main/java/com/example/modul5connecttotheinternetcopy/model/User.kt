package com.example.modul5connecttotheinternetcopy.model

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Serializable
@Entity(tableName = "users")
data class User(
    @PrimaryKey val email: String,
    val gender: String,
    @Embedded val name: Name,
    @Embedded val location: Location,
    val phone: String,
    val cell: String,
    @Embedded val picture: Picture
)

@Serializable
data class Name(
    val title: String,
    val first: String,
    val last: String
)

@Serializable
data class Location(
    @Embedded val street: Street,
    val city: String,
    val state: String,
    val country: String,
    val postcode: Int
)

@Serializable
data class Street(
    val number: Int,
    val name: String
)

@Serializable
data class Picture(
    val large: String,
    val medium: String,
    val thumbnail: String
)