package com.example.modul5connecttotheinternetcopy.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.modul5connecttotheinternetcopy.viewmodel.MovieViewModel

class MovieViewModelFactory : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return MovieViewModel() as T
    }
}