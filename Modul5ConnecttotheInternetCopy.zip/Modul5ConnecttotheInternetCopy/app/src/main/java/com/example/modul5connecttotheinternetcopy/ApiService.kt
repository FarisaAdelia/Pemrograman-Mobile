package com.example.modul5connecttotheinternetcopy

import com.example.modul5connecttotheinternetcopy.model.UserResponse
import retrofit2.http.GET

interface ApiService {
    @GET("api/")
    suspend fun getRandomUser(): UserResponse
}
