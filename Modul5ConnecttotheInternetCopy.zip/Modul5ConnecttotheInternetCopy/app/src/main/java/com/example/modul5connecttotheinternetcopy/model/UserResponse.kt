package com.example.modul5connecttotheinternetcopy.model

import com.example.modul5connecttotheinternetcopy.model.User
import kotlinx.serialization.Serializable

@Serializable
data class UserResponse(
    val results: List<User>
)