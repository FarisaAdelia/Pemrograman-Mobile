package com.example.modul5connecttotheinternetcopy.viewmodel

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.modul5connecttotheinternetcopy.data.AppDatabase
import com.example.modul5connecttotheinternetcopy.RetrofitInstance
import com.example.modul5connecttotheinternetcopy.data.UserRepository
import com.example.modul5connecttotheinternetcopy.viewmodel.UserViewModel

class UserViewModelFactory(private val application: Application) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(UserViewModel::class.java)) {
            val database = AppDatabase.getDatabase(application)
            val userDao = database.userDao()
            val apiService = RetrofitInstance.api
            val repository = UserRepository(apiService, userDao)
            return UserViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}