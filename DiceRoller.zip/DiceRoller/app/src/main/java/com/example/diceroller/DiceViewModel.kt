package com.example.diceroller

import androidx.lifecycle.ViewModel
import kotlin.random.Random

class DiceViewModel : ViewModel() {
    var dice1Value: Int = 0
        private set
    var dice2Value: Int = 0
        private set

    fun rollDice() {
        dice1Value = Random.nextInt(1, 7)
        dice2Value = Random.nextInt(1, 7)
    }

    fun getResultMessage(): String {
        return if (dice1Value == dice2Value) {
            "Selamat anda dapat dadu double!"
        } else {
            "Anda belum beruntung!"
        }
    }
}
