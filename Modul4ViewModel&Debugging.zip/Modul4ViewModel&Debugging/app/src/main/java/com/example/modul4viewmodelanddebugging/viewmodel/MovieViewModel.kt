package com.example.modul4viewmodelanddebugging.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import com.example.modul4viewmodelanddebugging.R
import com.example.modul4viewmodelanddebugging.model.MovieItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class MovieViewModel : ViewModel() {

    private val _movies = MutableStateFlow<List<MovieItem>>(emptyList())
    val movies: StateFlow<List<MovieItem>> = _movies

    private val _selectedMovie = MutableStateFlow<MovieItem?>(null)
    val selectedMovie: StateFlow<MovieItem?> = _selectedMovie

    init {
        val sample = listOf(
            MovieItem(1, "Pengabdi Setan 2: Communion", "2022", "When the heavy storm hits...", R.drawable.pengabdi, "https://www.imdb.com"),
            MovieItem(2, "Siksa Kubur", "2024", "Tells about the punishment of the grave...", R.drawable.siksa, "https://www.imdb.com"),
            MovieItem(3, "Pengepungan di Bukit Duri", "2025", "A special school for troubled children...", R.drawable.bukitduri, "https://www.imdb.com")
        )

        Log.d("MovieViewModel", "Data masuk ke dalam list: ${sample.size} item")
        _movies.value = sample
    }

    fun selectMovie(movie: MovieItem) {
        Log.d("MovieViewModel", "Data yang dipilih untuk detail: $movie")
        _selectedMovie.value = movie
    }

    fun onImdbClick(movie: MovieItem) {
        Log.d("MovieViewModel", "Tombol IMDB ditekan: ${movie.title}")
    }

    fun onDetailClick(movie: MovieItem) {
        Log.d("MovieViewModel", "Tombol Detail ditekan: ${movie.title}")
    }
}
