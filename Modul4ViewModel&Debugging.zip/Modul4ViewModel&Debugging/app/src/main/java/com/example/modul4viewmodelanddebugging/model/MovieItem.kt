package com.example.modul4viewmodelanddebugging.model

data class MovieItem(
    val id: Int,
    val title: String,
    val year: String,
    val plot: String,
    val imageResId: Int,
    val imdbLink: String
)